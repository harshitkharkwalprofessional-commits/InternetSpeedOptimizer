package com.example.internetspeedoptimizer

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.net.*
import android.net.wifi.WifiManager
import android.os.*
import android.provider.Settings
import android.telephony.*
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var signal: TextView
    private lateinit var monitor: TextView
    private lateinit var speed: TextView
    private lateinit var dnsInput: EditText
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var callback: ConnectivityManager.NetworkCallback? = null
    private val cm by lazy { getSystemService(ConnectivityManager::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestSignalPermissions()
        updateNetwork()
        startMonitoring()
        refreshSignal()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 30, 36, 30)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        scroll.addView(layout)
        setContentView(scroll)

        fun heading(t: String, size: Float = 22f) {
            layout.addView(TextView(this).apply {
                text = t; textSize = size; setTextColor(0xFF102A43.toInt())
                setPadding(0, 16, 0, 8)
            })
        }
        fun label(t: String): TextView = TextView(this).apply {
            text = t; textSize = 16f; setTextColor(0xFF334E68.toInt())
            setPadding(0, 5, 0, 12)
        }
        fun button(t: String, action: () -> Unit) {
            layout.addView(Button(this).apply {
                text = t; isAllCaps = false
                setOnClickListener { action() }
            }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        heading("⚡ Internet Speed Optimizer", 25f)
        layout.addView(label("Tools for Wi-Fi and mobile data. Android controls some network settings for your safety."))
        heading("Connection")
        status = label("Checking connection…")
        layout.addView(status)
        button("Refresh connection") { updateNetwork(); refreshSignal() }

        heading("Speed test")
        speed = label("Not tested yet. Uses Cloudflare's public speed-test endpoint; data charges may apply.")
        layout.addView(speed)
        button("Run speed test") { runSpeedTest() }

        heading("Network monitor")
        monitor = label("Monitoring will start automatically.")
        layout.addView(monitor)

        heading("Signal strength")
        signal = label("Checking signal…")
        layout.addView(signal)
        button("Refresh signal strength") { refreshSignal() }

        heading("DNS optimization")
        layout.addView(label("Choose a trusted Private DNS provider. Android will ask you to confirm the system setting."))
        dnsInput = EditText(this).apply {
            hint = "dns.google or one.one.one.one"
            setSingleLine(true)
            setText("dns.google")
        }
        layout.addView(dnsInput)
        button("Open Private DNS settings") { openDnsSettings() }
        button("Open Wi-Fi settings") { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        button("Open mobile network settings") { startActivity(Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS)) }

        layout.addView(label("Tips: move closer to the router, switch off unused VPNs, pause large downloads, and compare Wi-Fi with mobile data. DNS mainly affects lookup time; it does not increase your carrier's bandwidth."))
    }

    private fun requestSignalPermissions() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.READ_PHONE_STATE)
        if (needed.isNotEmpty() && Build.VERSION.SDK_INT >= 23)
            requestPermissions(needed.toTypedArray(), 42)
    }

    private fun updateNetwork() {
        val n = cm.activeNetwork
        val caps = n?.let { cm.getNetworkCapabilities(it) }
        val type = when {
            caps == null -> "No active internet connection"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Connected via Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Connected via mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Connected via Ethernet"
            else -> "Connected (other network)"
        }
        val internet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        status.text = "$type\nInternet capability: ${if (internet) "Yes" else "No"}\nValidated internet: ${if (validated) "Yes" else "Not confirmed"}"
    }

    private fun startMonitoring() {
        val request = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { handler.post { updateNetwork(); monitor.text = "Network available. Monitoring connection changes." } }
            override fun onLost(network: Network) { handler.post { updateNetwork(); monitor.text = "Network lost. Check Wi-Fi/mobile data." } }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                handler.post {
                    val down = caps.linkDownstreamBandwidthKbps / 1000
                    val up = caps.linkUpstreamBandwidthKbps / 1000
                    monitor.text = "Network estimate: ${down} Mbps down / ${up} Mbps up\nThese are link estimates, not measured throughput."
                }
            }
        }
        callback = cb
        try { cm.registerNetworkCallback(request, cb) } catch (_: Exception) {}
    }

    private fun refreshSignal() {
        try {
            val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val info = wifi.connectionInfo
            if (cm.activeNetwork?.let { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) } == true) {
                val dbm = info.rssi
                val quality = when {
                    dbm >= -50 -> "Excellent"
                    dbm >= -60 -> "Good"
                    dbm >= -70 -> "Fair"
                    dbm > -100 -> "Weak"
                    else -> "Unavailable"
                }
                signal.text = "Wi-Fi RSSI: ${dbm} dBm ($quality)"
            } else {
                signal.text = cellularSignalText()
            }
        } catch (e: Exception) {
            signal.text = "Signal details unavailable. Check permissions and Android location settings."
        }
    }

    private fun cellularSignalText(): String {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            return "Mobile signal details require Phone and Location permissions."
        return try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            val cells = tm.allCellInfo
            val dbm = cells?.firstOrNull { it.isRegistered }?.let {
                when (it) {
                    is CellInfoLte -> it.cellSignalStrength.dbm
                    is CellInfoGsm -> it.cellSignalStrength.dbm
                    is CellInfoWcdma -> it.cellSignalStrength.dbm
                    is CellInfoNr -> it.cellSignalStrength.dbm
                    else -> Int.MAX_VALUE
                }
            }
            if (dbm == null || dbm == Int.MAX_VALUE) "Mobile signal: unavailable (carrier/Android may restrict readings)"
            else "Mobile signal: $dbm dBm"
        } catch (_: SecurityException) {
            "Mobile signal details unavailable: permission denied."
        } catch (_: Exception) {
            "Mobile signal details unavailable on this device."
        }
    }

    private fun openDnsSettings() {
        val host = dnsInput.text.toString().trim()
        if (host.isNotEmpty() && (host.contains("://") || host.contains("/") || host.contains(" "))) {
            Toast.makeText(this, "Enter a hostname only, e.g. dns.google", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startActivity(Intent("android.settings.PRIVATE_DNS_SETTINGS"))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }
        Toast.makeText(this, "In Private DNS, choose Private DNS provider hostname and enter: ${host.ifBlank { "dns.google" }}", Toast.LENGTH_LONG).show()
    }

    private fun runSpeedTest() {
        speed.text = "Running download test…"
        executor.execute {
            try {
                val bytes = 8 * 1024 * 1024
                val url = URL("https://speed.cloudflare.com/__down?bytes=$bytes")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000; readTimeout = 30000
                    setRequestProperty("Cache-Control", "no-cache")
                }
                val start = System.nanoTime()
                var total = 0L
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val count = input.read(buf)
                        if (count < 0) break
                        total += count
                    }
                }
                conn.disconnect()
                val seconds = (System.nanoTime() - start) / 1_000_000_000.0
                val mbps = (total * 8.0 / seconds / 1_000_000.0)
                handler.post { speed.text = "Download: ${"%.2f".format(mbps)} Mbps\nDownloaded ${"%.1f".format(total / 1_048_576.0)} MB in ${"%.1f".format(seconds)} s\nUpload test is not included in this first version." }
            } catch (e: Exception) {
                handler.post { speed.text = "Speed test failed: ${e.localizedMessage ?: "network error"}. Check your connection and try again." }
            }
        }
    }

    override fun onDestroy() {
        callback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        executor.shutdownNow()
        super.onDestroy()
    }
}
