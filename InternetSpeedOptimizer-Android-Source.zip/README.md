# Internet Speed Optimizer (Android)

## Included
- Download speed test using Cloudflare's public speed-test download endpoint (downloads about 8 MiB per run).
- Active connection detection for Wi-Fi/mobile data.
- Network availability/loss monitoring and Android-reported link bandwidth estimates.
- Wi-Fi RSSI and best-effort registered cellular cell signal readings.
- Private DNS helper that opens Android system settings. Android requires the user to apply Private DNS; the app does not silently alter protected system settings.

## Build an installable APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install any prompted SDK/build tools.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer it to your Android phone and install it. You may need to allow your file manager to install unknown apps.

Command line (with JDK 17 and Android SDK configured):
`gradle assembleDebug`
The APK will be in `app/build/outputs/apk/debug/`.

## Notes and limitations
- This source project is provided; an APK has not been compiled or device-tested in this environment.
- Speed test consumes data (approximately 8 MiB each run, plus protocol overhead).
- DNS changes can improve DNS lookup responsiveness in some cases, but do not increase raw internet bandwidth. `dns.google` is Google Public DNS; `one.one.one.one` is Cloudflare DNS.
- Signal readings vary by device, Android version, carrier, and permission/location settings. Some devices restrict cellular cell information.
- Android does not allow ordinary apps to force-switch Wi-Fi/mobile data, change protected network settings silently, or guarantee faster speeds.
- The app does not collect or upload personal data. The speed-test request goes to Cloudflare.
